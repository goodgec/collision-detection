var searchData=
[
  ['algchecker',['AlgChecker',['../classAlgChecker.html',1,'AlgChecker'],['../classAlgChecker.html#a6757c95725ca49e224ae8d7b63c036f3',1,'AlgChecker::AlgChecker()']]],
  ['algorithm',['Algorithm',['../classAlgorithm.html',1,'Algorithm'],['../classAlgorithm.html#a4b8b963f5c1b58c0c2402d9812ce4742',1,'Algorithm::Algorithm(double xIn, double yIn)'],['../classAlgorithm.html#afd02a93b4a04adb18a1332cfc2fcd84f',1,'Algorithm::Algorithm(double xIn, double yIn, double zIn)'],['../classAlgorithm.html#a931280a684c9877eeee3f2d48a1541df',1,'Algorithm::Algorithm(double xIn, double yIn, double zIn, double centerMass)']]]
];
